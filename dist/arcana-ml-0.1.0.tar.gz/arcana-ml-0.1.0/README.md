# Arcana Toolkit

Arcana is a simple library developped by myself in my free-time to learn how works some machine learning models and how to implement them.

I also try to make some personnal stuff as "custom" machine learning algorithm.

I try to use the less librairies possible.

## Installation

Clone this repository with this following command.

```bash
git clone https://github.com/lumaes/Arcana-ml-toolkit/
pip install -r requirements.txt
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
